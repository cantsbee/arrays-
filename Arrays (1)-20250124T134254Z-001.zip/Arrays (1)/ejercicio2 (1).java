public class ejercicio2 {
    public static void main(String[] args) {
        
    int a[],b[];
    a=new int[10];
    b=a;
    
 // int a[]={22,44,12,13,14,15,16,17,18,19};
System.out.println(a);
System.out.println(b);
    }

}
