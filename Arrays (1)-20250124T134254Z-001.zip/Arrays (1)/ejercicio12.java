import java.util.Arrays;
import java.util.Scanner;


public class ejercicio12 {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        String ciudades[]={ "Madrid", "Barcelona ", " Valencia ", " Jaen ", " Malaga ", "Madrid ", "Valencia ", " Madrid ", " Barcelona "};
        System.out.println("Escribe la ciudad que quieres localizar y 'salir' para salir del programa ");
        String x= lector.nextLine();
       
        while(!x.equalsIgnoreCase("salir")){
            System.out.println("introduce una ciudad ");
            x=lector.nextLine();
            int posInicial=-1;
            int posFinal=-1;
            if(int i=0; i<=ciudades.length; i++){
                
            }
        }

    }
}